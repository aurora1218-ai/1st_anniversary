import { content } from './content';
import { memories, extraMemories, worldMemories, type GalleryImage } from './gallery-data';
import { renderMusic } from './music';

const allImages = [...memories, ...extraMemories, ...worldMemories];

const flower = `<svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M20 19C10 15 13 5 20 7C27 5 30 15 20 19ZM21 20C23 9 34 10 33 17C37 23 28 29 21 20ZM20 21C31 21 33 32 26 33C21 39 13 31 20 21ZM19 21C22 31 12 36 9 30C2 27 8 17 19 21ZM18 20C9 27 1 19 6 14C7 6 18 9 18 20Z" stroke="currentColor" stroke-width=".8"/><circle cx="20" cy="20" r="1.6" fill="currentColor"/></svg>`;

const arrow = `<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 12h15m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

const escapeHtml = (value: string): string => value.replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character] ?? character);

const lines = (values: string[]): string => values.map(escapeHtml).join('<br>');

function photo(image: GalleryImage, className = '', sizes = '(max-width: 700px) 88vw, 55vw'): string {
  const imageIndex = allImages.indexOf(image);
  return `<figure class="memory-photo ${className}" data-reveal>
    <button class="photo-button" type="button" data-image-index="${imageIndex}" aria-label="${escapeHtml(`${content.gallery.open}：${image.title ?? image.alt}`)}">
      <img class="photo-image" src="${image.srcSmall}" srcset="${image.srcSmall} ${Math.min(800, image.width)}w, ${image.src} ${Math.min(1800, image.width)}w" sizes="${sizes}" width="${image.width}" height="${image.height}" alt="${escapeHtml(image.alt)}" loading="lazy" decoding="async">
      <span class="image-open" aria-hidden="true"><span>＋</span> ${content.gallery.open}</span>
    </button>
    <figcaption><span class="photo-title">${escapeHtml(image.title ?? '')}</span><span class="photo-caption">${escapeHtml(image.caption)}</span></figcaption>
  </figure>`;
}

export function renderPage(): string {
  return `
    <a class="skip-link" href="#light">跳到正文</a>
    <div id="scene" class="scene-backdrop" aria-hidden="true"></div>
    <div class="scene-vignette" aria-hidden="true"></div>
    <div id="atmosphere" class="atmosphere" aria-hidden="true"></div>
    <div class="ambient-grain" aria-hidden="true"></div>
    <header class="site-header">
      <a class="dedication-mark" href="#start" aria-label="回到月下相遇">${flower}<span>致 晓</span></a>
      <nav class="top-nav" aria-label="章节导航">${content.navigation.map((item) => `<a href="${item.href}">${item.label}</a>`).join('')}</nav>
    </header>
    <nav class="chapter-nav" aria-label="章节位置">${content.chapters.map((item, index) => `<a href="${item.href}" class="chapter-link${index === 0 ? ' is-active' : ''}" ${index === 0 ? 'aria-current="true"' : ''} aria-label="${item.label}"><span class="chapter-dot"></span><span class="chapter-label">${item.label}</span></a>`).join('')}</nav>
    <main>
      <section id="start" class="hero" aria-labelledby="hero-title">
        <div class="hero-copy">
          <p class="eyebrow hero-eyebrow">${content.hero.dedication}</p>
          <h1 id="hero-title" aria-label="${content.hero.title}"><span class="hero-recipient">${content.hero.recipient}</span> <span class="hero-anniversary"><span aria-hidden="true">·</span> ${content.hero.anniversary}</span></h1>
          <p class="hero-line">${content.hero.line}</p>
          <span class="hero-rule" aria-hidden="true"></span>
        </div>
        <a class="scroll-invitation" href="#light"><span class="scroll-line" aria-hidden="true"></span><span>${content.hero.scroll}</span></a>
        <p class="hero-footnote">${content.hero.footnote}</p>
      </section>

      <section id="light" class="story-section memory-section" aria-labelledby="light-title">
        <div class="section-shell">
          <div class="section-heading memory-heading" data-reveal>
            <p class="eyebrow">${content.light.eyebrow}</p>
            <h2 id="light-title">${content.light.title}</h2>
            <p class="section-introduction">${lines(content.light.introduction)}</p>
          </div>
          <div class="memory-opening">
            <div class="memory-spring">
              ${photo(memories[0], 'photo-cherry')}
              <p class="small-poem music-note" data-reveal><span class="poem-rule" aria-hidden="true"></span>${lines(content.light.music)}</p>
            </div>
            <div class="memory-moon">
              ${photo(memories[5], 'photo-moon', '(max-width: 700px) 55vw, 25vw')}
              <p class="quiet-caption" data-reveal>${lines(content.light.moon)}</p>
            </div>
          </div>
          <div class="memory-water">
            <p class="small-poem water-note" data-reveal>${lines(content.light.water)}</p>
            ${photo(memories[1], 'photo-lake', '(max-width: 700px) 88vw, 65vw')}
          </div>
          <div class="memory-trio">
            ${photo(memories[2], 'photo-willow', '(max-width: 700px) 72vw, 29vw')}
            ${photo(memories[3], 'photo-sunset', '(max-width: 700px) 72vw, 29vw')}
            ${photo(memories[4], 'photo-evening', '(max-width: 700px) 72vw, 29vw')}
          </div>
          <p class="section-coda" data-reveal>${content.light.ending}</p>
          <div class="shared-worlds">
            <div class="shared-worlds-heading" data-reveal>
              <p class="eyebrow">${content.light.collection.eyebrow}</p>
              <h3>${content.light.collection.title}</h3>
              <p class="section-introduction">${content.light.collection.introduction}</p>
            </div>
            ${photo(extraMemories[3], 'dream-panorama', '(max-width: 700px) 88vw, 82vw')}
            <div class="light-reel" aria-label="${content.light.collection.reelLabel}" tabindex="0">
              ${extraMemories.slice(0, 3).map((image) => photo(image, 'reel-photo', '(max-width: 700px) 78vw, 31vw')).join('')}
            </div>
            <div class="paper-collection" aria-label="${content.light.collection.paperLabel}">
              ${photo(extraMemories[4], 'collection-poem', '(max-width: 700px) 75vw, 29vw')}
              <div class="collection-warmth">
                <p class="small-poem collection-note" data-reveal>${content.light.collection.pages}</p>
                ${photo(extraMemories[6], 'collection-girl', '(max-width: 700px) 55vw, 24vw')}
              </div>
              ${photo(extraMemories[5], 'collection-sunbird', '(max-width: 700px) 40vw, 17vw')}
            </div>
          </div>
        </div>
      </section>

      <section class="star-interlude" aria-label="${content.sky.eyebrow}">
        <div id="star-sky" aria-hidden="true"></div>
        <div class="star-interlude-copy" data-reveal>
          <p class="eyebrow">${content.sky.eyebrow}</p>
          <p class="star-interlude-line">${content.sky.line}</p>
          <p class="star-interlude-small">${content.sky.small}</p>
        </div>
      </section>

      <section id="world" class="story-section world-section" aria-labelledby="world-title">
        <div class="section-shell">
          <div class="section-heading world-heading" data-reveal>
            <p class="eyebrow">${content.world.eyebrow}</p>
            <h2 id="world-title">${content.world.title}</h2>
            <p class="section-introduction">${lines(content.world.introduction)}</p>
          </div>
          <div class="world-feature">
            <span class="world-annotation" data-reveal>${content.world.note}</span>
            ${photo(worldMemories[0], 'world-main-photo', '(max-width: 700px) 88vw, 80vw')}
          </div>
          <div class="world-rail" aria-label="${content.world.railLabel}" tabindex="0">
            ${worldMemories.slice(1).map((image) => photo(image, 'world-small-photo', '(max-width: 700px) 78vw, 30vw')).join('')}
          </div>
          <p class="world-rail-hint"><span aria-hidden="true">←</span>${content.world.railHint}<span aria-hidden="true">→</span></p>
          <p class="section-coda" data-reveal>${content.world.ending}</p>
        </div>
      </section>

      <section id="letter" class="story-section letter-section" aria-labelledby="letter-title">
        <div class="section-shell letter-shell">
          <div class="section-heading letter-heading" data-reveal>
            <p class="eyebrow">${content.letter.eyebrow}</p>
            <h2 id="letter-title">${content.letter.title}</h2>
          </div>
          <article class="letter-card" data-reveal>
            <span class="paper-corner paper-corner--left" aria-hidden="true"></span><span class="paper-corner paper-corner--right" aria-hidden="true"></span>
            <button class="letter-toggle" type="button" aria-expanded="false" aria-controls="letter-body">
              <span class="letter-address">${content.letter.to}</span>
              <span class="letter-seal" aria-hidden="true">${flower}</span>
              <span class="letter-action"><span data-letter-action>${content.letter.openLabel}</span>${arrow}</span>
            </button>
            <div id="letter-body" class="letter-body" hidden>
              <div class="letter-inner">
                <p class="letter-greeting">${content.letter.greeting}</p>
                ${content.letter.paragraphs.map((paragraph) => `<p>${paragraph}</p>`).join('')}
                <p class="letter-signature"><span>${content.signature}</span><span class="signature-flower" aria-hidden="true">${flower}</span></p>
              </div>
            </div>
            <span class="paper-bottom-rule" aria-hidden="true"></span>
          </article>
        </div>
      </section>

      <section class="closing" aria-label="下一页">
        <div class="closing-copy" data-reveal>
          <span class="closing-flower" aria-hidden="true">${flower}</span>
          <p class="closing-line">${content.closing.line}</p>
          <p class="closing-small">${content.closing.small}</p>
          <a class="return-link" href="#start">${content.closing.returnLabel}<span aria-hidden="true">↑</span></a>
        </div>
        <footer class="site-footer"><span>致 ${content.recipient}</span><span class="footer-line" aria-hidden="true"></span><span>${content.signature}</span></footer>
      </section>
    </main>

    ${renderMusic()}
    <dialog class="lightbox" aria-label="照片画廊" aria-describedby="lightbox-caption">
      <div class="lightbox-shell">
        <div class="lightbox-top"><span class="lightbox-title"></span><button class="lightbox-close" type="button" aria-label="${content.gallery.close}"><span aria-hidden="true">×</span></button></div>
        <div class="lightbox-image-wrap"><img class="lightbox-image" alt=""></div>
        <div class="lightbox-bottom"><p id="lightbox-caption" class="lightbox-caption"></p><div class="lightbox-controls"><button type="button" data-lightbox-prev aria-label="${content.gallery.previous}">←</button><span class="lightbox-counter" aria-live="polite"></span><button type="button" data-lightbox-next aria-label="${content.gallery.next}">→</button><span class="control-divider" aria-hidden="true"></span><button type="button" data-lightbox-zoom-in aria-label="${content.gallery.zoomIn}">＋</button><button type="button" data-lightbox-zoom-out aria-label="${content.gallery.zoomOut}">−</button></div></div>
        <p class="lightbox-hint">${content.gallery.hint}</p>
      </div>
    </dialog>`;
}

export function initPage(): () => void {
  const cleanupCallbacks: Array<() => void> = [];
  const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  const revealElements = document.querySelectorAll<HTMLElement>('[data-reveal]');
  let revealObserver: IntersectionObserver | undefined;

  const applyMotionPreference = (): void => {
    const canAnimate = !motionQuery.matches && 'IntersectionObserver' in window;
    document.documentElement.classList.toggle('has-motion', canAnimate);
    if (!canAnimate) revealElements.forEach((element) => element.classList.add('is-visible'));
  };
  applyMotionPreference();
  motionQuery.addEventListener('change', applyMotionPreference);
  cleanupCallbacks.push(() => motionQuery.removeEventListener('change', applyMotionPreference));
  if ('IntersectionObserver' in window) {
    revealObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver?.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -24px 0px' });
    revealElements.forEach((element) => revealObserver?.observe(element));
  }

  let chapterObserver: IntersectionObserver | undefined;
  if ('IntersectionObserver' in window) {
    chapterObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        document.querySelectorAll<HTMLAnchorElement>('.chapter-link').forEach((link) => {
          const active = link.hash === `#${entry.target.id}`;
          link.classList.toggle('is-active', active);
          if (active) link.setAttribute('aria-current', 'true');
          else link.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-25% 0px -65% 0px' });
    document.querySelectorAll<HTMLElement>('main section[id]').forEach((section) => chapterObserver?.observe(section));
  }

  const letterToggle = document.querySelector<HTMLButtonElement>('.letter-toggle');
  const letterBody = document.querySelector<HTMLElement>('.letter-body');
  const letterCard = document.querySelector<HTMLElement>('.letter-card');
  const letterAction = document.querySelector<HTMLElement>('[data-letter-action]');
  const toggleLetter = (): void => {
    if (!letterToggle || !letterBody || !letterCard) return;
    const open = letterToggle.getAttribute('aria-expanded') !== 'true';
    letterToggle.setAttribute('aria-expanded', String(open));
    letterBody.hidden = !open;
    letterCard.classList.toggle('is-open', open);
    if (letterAction) letterAction.textContent = open ? content.letter.closeLabel : content.letter.openLabel;
  };
  letterToggle?.addEventListener('click', toggleLetter);
  cleanupCallbacks.push(() => letterToggle?.removeEventListener('click', toggleLetter));

  const dialog = document.querySelector<HTMLDialogElement>('.lightbox');
  const lightboxImage = document.querySelector<HTMLImageElement>('.lightbox-image');
  const lightboxTitle = document.querySelector<HTMLElement>('.lightbox-title');
  const lightboxCaption = document.querySelector<HTMLElement>('.lightbox-caption');
  const lightboxCounter = document.querySelector<HTMLElement>('.lightbox-counter');
  const imageWrap = document.querySelector<HTMLElement>('.lightbox-image-wrap');
  const closeButton = document.querySelector<HTMLButtonElement>('.lightbox-close');
  const previousButton = document.querySelector<HTMLButtonElement>('[data-lightbox-prev]');
  const nextButton = document.querySelector<HTMLButtonElement>('[data-lightbox-next]');
  const zoomInButton = document.querySelector<HTMLButtonElement>('[data-lightbox-zoom-in]');
  const zoomOutButton = document.querySelector<HTMLButtonElement>('[data-lightbox-zoom-out]');
  let activeImageIndex = 0;
  let previousFocus: HTMLElement | null = null;
  let touchStartX = 0;
  let touchStartY = 0;

  const setZoom = (zoomed: boolean): void => {
    dialog?.classList.toggle('is-zoomed', zoomed);
    if (zoomInButton) zoomInButton.disabled = zoomed;
    if (zoomOutButton) zoomOutButton.disabled = !zoomed;
    if (imageWrap) imageWrap.scrollTo(0, 0);
  };
  const displayImage = (imageIndex: number): void => {
    activeImageIndex = (imageIndex + allImages.length) % allImages.length;
    const image = allImages[activeImageIndex];
    if (!lightboxImage) return;
    lightboxImage.src = image.src;
    lightboxImage.alt = image.alt;
    lightboxImage.width = image.width;
    lightboxImage.height = image.height;
    if (lightboxTitle) lightboxTitle.textContent = image.title ?? '';
    if (lightboxCaption) lightboxCaption.textContent = image.caption;
    if (lightboxCounter) lightboxCounter.textContent = `${String(activeImageIndex + 1).padStart(2, '0')} / ${String(allImages.length).padStart(2, '0')}`;
    setZoom(false);
  };
  const openImage = (imageIndex: number): void => {
    if (!dialog) return;
    previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    displayImage(imageIndex);
    document.documentElement.classList.add('gallery-open');
    dialog.showModal();
    closeButton?.focus({ preventScroll: true });
  };
  const closeImage = (): void => { dialog?.close(); };
  const onDialogClose = (): void => {
    document.documentElement.classList.remove('gallery-open');
    setZoom(false);
    previousFocus?.focus({ preventScroll: true });
  };
  const previousImage = (): void => displayImage(activeImageIndex - 1);
  const nextImage = (): void => displayImage(activeImageIndex + 1);
  const zoomIn = (): void => setZoom(true);
  const zoomOut = (): void => setZoom(false);
  const onKeyDown = (event: KeyboardEvent): void => {
    if (!dialog?.open) return;
    if (event.key === 'ArrowLeft') { event.preventDefault(); previousImage(); }
    if (event.key === 'ArrowRight') { event.preventDefault(); nextImage(); }
  };
  const onBackdropClick = (event: MouseEvent): void => { if (event.target === dialog) closeImage(); };
  const onPointerDown = (event: PointerEvent): void => { touchStartX = event.clientX; touchStartY = event.clientY; };
  const onPointerUp = (event: PointerEvent): void => {
    if (event.pointerType === 'mouse' || dialog?.classList.contains('is-zoomed')) return;
    const distanceX = event.clientX - touchStartX;
    const distanceY = event.clientY - touchStartY;
    if (Math.abs(distanceX) > 48 && Math.abs(distanceX) > Math.abs(distanceY) * 1.4) {
      if (distanceX < 0) nextImage();
      else previousImage();
    }
  };
  document.querySelectorAll<HTMLButtonElement>('[data-image-index]').forEach((button) => {
    const handler = (): void => openImage(Number(button.dataset.imageIndex));
    button.addEventListener('click', handler);
    cleanupCallbacks.push(() => button.removeEventListener('click', handler));
  });
  closeButton?.addEventListener('click', closeImage);
  previousButton?.addEventListener('click', previousImage);
  nextButton?.addEventListener('click', nextImage);
  zoomInButton?.addEventListener('click', zoomIn);
  zoomOutButton?.addEventListener('click', zoomOut);
  dialog?.addEventListener('close', onDialogClose);
  dialog?.addEventListener('click', onBackdropClick);
  imageWrap?.addEventListener('pointerdown', onPointerDown);
  imageWrap?.addEventListener('pointerup', onPointerUp);
  document.addEventListener('keydown', onKeyDown);

  return () => {
    revealObserver?.disconnect();
    chapterObserver?.disconnect();
    cleanupCallbacks.forEach((cleanup) => cleanup());
    closeButton?.removeEventListener('click', closeImage);
    previousButton?.removeEventListener('click', previousImage);
    nextButton?.removeEventListener('click', nextImage);
    zoomInButton?.removeEventListener('click', zoomIn);
    zoomOutButton?.removeEventListener('click', zoomOut);
    dialog?.removeEventListener('close', onDialogClose);
    dialog?.removeEventListener('click', onBackdropClick);
    imageWrap?.removeEventListener('pointerdown', onPointerDown);
    imageWrap?.removeEventListener('pointerup', onPointerUp);
    document.removeEventListener('keydown', onKeyDown);
    document.documentElement.classList.remove('has-motion', 'gallery-open');
  };
}
