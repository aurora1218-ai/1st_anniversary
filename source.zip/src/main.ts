import './fonts.css';
import './style.css';
import { renderPage, initPage } from './page';
import { createScene } from './scene';
import { createStarSky } from './star-sky';
import { createAtmosphere } from './ambient-particles';
import { initMusic } from './music';

const app = document.querySelector<HTMLElement>('#app');

if (app) {
  app.innerHTML = renderPage();
  const disposePage = initPage();
  const disposeMusic = initMusic();
  const sceneHost = document.querySelector<HTMLElement>('#scene');
  const disposeScene = sceneHost ? createScene(sceneHost) : () => undefined;
  const starHost = document.querySelector<HTMLElement>('#star-sky');
  const disposeStars = starHost ? createStarSky(starHost) : () => undefined;
  const atmosphereHost = document.querySelector<HTMLElement>('#atmosphere');
  const disposeAtmosphere = atmosphereHost ? createAtmosphere(atmosphereHost) : () => undefined;

  window.addEventListener('pagehide', (event) => {
    if (!event.persisted) {
      disposePage();
      disposeScene();
      disposeStars();
      disposeAtmosphere();
      disposeMusic();
    }
  }, { once: true });
}
