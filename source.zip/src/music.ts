const track = {
  title: 'MONACA · きっと彼女は_（她一定是。）· Inst.',
  caption: 'MONACA · 她一定是。',
  sources: [
    { src: `${import.meta.env.BASE_URL}audio/monaca-kitto-kanojo-wa.m4a`, type: 'audio/mp4' },
    { src: `${import.meta.env.BASE_URL}audio/monaca-kitto-kanojo-wa.ogg`, type: 'audio/ogg' },
  ],
  volume: .38,
};

export function renderMusic(): string {
  return `<aside class="music-player" aria-label="背景音乐">
    <p class="music-track" id="music-track">${track.caption}</p>
    <button class="music-toggle" type="button" aria-label="播放背景音乐" aria-pressed="false" aria-describedby="music-track" title="${track.title}">
      <span class="music-orbit" aria-hidden="true"><span class="music-bars"><span></span><span></span><span></span><span></span></span></span>
      <span class="music-label">听听这一年</span><span class="music-spark" aria-hidden="true">✦</span>
    </button>
    <span class="music-status" role="status" aria-live="polite"></span>
    <audio class="background-music" preload="auto" autoplay loop>${track.sources.map((source) => `<source src="${source.src}" type="${source.type}">`).join('')}</audio>
  </aside>`;
}

export function initMusic(): () => void {
  const audio = document.querySelector<HTMLAudioElement>('.background-music');
  const button = document.querySelector<HTMLButtonElement>('.music-toggle');
  const player = document.querySelector<HTMLElement>('.music-player');
  const label = document.querySelector<HTMLElement>('.music-label');
  const status = document.querySelector<HTMLElement>('.music-status');
  if (!audio || !button || !player || !label || !status) return () => undefined;

  let wantsPlayback = false;
  let disposed = false;
  let requestVersion = 0;
  let fadeFrame = 0;
  let playbackError = false;
  let awaitingGesture = false;

  const stopFade = (): void => {
    window.cancelAnimationFrame(fadeFrame);
    fadeFrame = 0;
  };
  const update = (loading = false): void => {
    const playing = wantsPlayback && !audio.paused;
    player.classList.toggle('is-playing', playing);
    player.classList.toggle('is-loading', loading);
    button.setAttribute('aria-pressed', String(wantsPlayback));
    button.setAttribute('aria-label', wantsPlayback ? '暂停背景音乐' : '播放背景音乐');
    label.textContent = playbackError ? '轻点重试' : loading ? '音乐载入中' : playing ? '音乐播放中' : awaitingGesture ? '轻触聆听' : '听听这一年';
  };
  const fadeIn = (): void => {
    stopFade();
    const started = performance.now();
    const frame = (now: number): void => {
      if (disposed || audio.paused || !wantsPlayback) return;
      const progress = Math.min(1, (now - started) / 1600);
      audio.volume = track.volume * progress * (2 - progress);
      if (progress < 1) fadeFrame = window.requestAnimationFrame(frame);
      else fadeFrame = 0;
    };
    fadeFrame = window.requestAnimationFrame(frame);
  };
  const removeGestureListeners = (): void => {
    document.removeEventListener('pointerdown', onFirstGesture);
    document.removeEventListener('keydown', onFirstGesture);
  };
  const onFirstGesture = (event: Event): void => {
    if (event.target instanceof Element && event.target.closest('.music-player')) return;
    if (event instanceof KeyboardEvent && ['Tab', 'Shift', 'Control', 'Alt', 'Meta', 'Escape'].includes(event.key)) return;
    removeGestureListeners();
    void startPlayback();
  };
  const startPlayback = async (): Promise<void> => {
    requestVersion++;
    const currentRequest = requestVersion;
    const reloadSource = playbackError || Boolean(audio.error);
    playbackError = false;
    awaitingGesture = false;
    removeGestureListeners();
    status.textContent = '';
    if (reloadSource) audio.load();
    wantsPlayback = true;
    audio.volume = 0;
    update(true);
    try {
      await audio.play();
      if (disposed || currentRequest !== requestVersion || !wantsPlayback) return;
      update();
      fadeIn();
    } catch (error) {
      if (disposed || currentRequest !== requestVersion) return;
      wantsPlayback = false;
      const blocked = error instanceof DOMException && error.name === 'NotAllowedError';
      playbackError = !blocked && !(error instanceof DOMException && error.name === 'AbortError');
      awaitingGesture = blocked;
      if (blocked) {
        document.addEventListener('pointerdown', onFirstGesture);
        document.addEventListener('keydown', onFirstGesture);
      }
      status.textContent = blocked ? '轻触页面，即可开始背景音乐。' : playbackError ? '音乐暂时未能播放，请轻点音乐按钮重试。' : '';
      update();
    }
  };
  const toggle = (): void => {
    if (wantsPlayback || !audio.paused) {
      requestVersion++;
      wantsPlayback = false;
      awaitingGesture = false;
      removeGestureListeners();
      stopFade();
      audio.pause();
      update();
    } else {
      void startPlayback();
    }
  };
  const onPlaying = (): void => update();
  const onWaiting = (): void => { if (wantsPlayback) update(true); };
  const onPause = (): void => {
    if (!audio.paused) return;
    wantsPlayback = false;
    stopFade();
    update();
  };
  const onError = (): void => {
    if (!audio.error) return;
    wantsPlayback = false;
    playbackError = true;
    stopFade();
    status.textContent = '音乐暂时未能播放，请轻点音乐按钮重试。';
    update();
  };
  button.addEventListener('click', toggle);
  audio.addEventListener('playing', onPlaying);
  audio.addEventListener('waiting', onWaiting);
  audio.addEventListener('pause', onPause);
  audio.addEventListener('error', onError);
  void startPlayback();

  return () => {
    disposed = true;
    stopFade();
    removeGestureListeners();
    button.removeEventListener('click', toggle);
    audio.removeEventListener('playing', onPlaying);
    audio.removeEventListener('waiting', onWaiting);
    audio.removeEventListener('pause', onPause);
    audio.removeEventListener('error', onError);
    audio.pause();
    audio.removeAttribute('src');
    audio.querySelectorAll('source').forEach((source) => source.removeAttribute('src'));
    audio.load();
  };
}
