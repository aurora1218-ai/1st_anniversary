import { defineConfig } from 'vite';

export default defineConfig({
  base: '/1st_anniversary/',
  build: {
    target: 'es2022',
    assetsDir: 'assets',
    sourcemap: false,
  },
});
