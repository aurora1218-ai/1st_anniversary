from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

project = Path(__file__).resolve().parent.parent
sources = project / '.tools' / 'font-sources'
output = project / 'public' / 'fonts'
output.mkdir(parents=True, exist_ok=True)
text = ''.join(
    source.read_text(encoding='utf-8')
    for source in (project / 'src').glob('*.ts')
)
text += (project / 'index.html').read_text(encoding='utf-8')
text += ''.join(chr(codepoint) for codepoint in range(32, 127))
text += '一二三四五六七八九十，。！？：；“”‘’《》（）…、·—＋×←→↑↓©榕晓'
characters = ''.join(sorted(set(text)))

for family in ['NotoSerifSC', 'NotoSansSC']:
    font = TTFont(sources / f'{family}.ttf')
    if 'fvar' in font:
        instantiateVariableFont(font, {'wght': 400}, inplace=True)
    options = subset.Options()
    options.flavor = 'woff2'
    options.desubroutinize = True
    options.layout_features = ['kern', 'liga', 'locl']
    processor = subset.Subsetter(options=options)
    processor.populate(text=characters)
    processor.subset(font)
    font.flavor = 'woff2'
    target = output / f'{family}-gift.woff2'
    font.save(target)
    print(f'{target.name}: {target.stat().st_size:,} bytes')

print(f'{len(characters)} unique characters prepared')
